x=0:0.01*pi:2*pi;    %定义x向量
figure(1);           %创建一个新的图形窗口,编号为1 

subplot(2,3,1);       %将窗口划分为2行2列,在第1个窗口中作图
plot(x,sin(x));       %画图
title('正弦线');      %给图形加标题

subplot(2,3,2);      %在第2个窗口中作图
plot(x,sin(x),'r');     %画一正弦波,红色
title('红色')
xlabel('X');         %给x轴加说明
ylabel('SIN(X)');    %给y轴加说明

subplot(2,3,3);      %在第3个窗口中作图
plot(x,sin(x),'--');    %画一正弦波,破折线

subplot(2,3,4);      %在第4个窗口中作图
plot(x,sin(x),'+r');   %画一正弦波,红色加号
text(4,0,'注记');     %在位置(4,0)处加一注记

subplot(2,3,5);
plot(x,cos(x),'r-o',x,sin(x),'-.b'); %在第五个窗口画余弦、正弦函数
g = legend('cos','sin','Best'); %注意图例不支持数字

subplot(2,3,6);
plot(x,cos(x/4),'-r',x,sin(x/8),'*b');
text(0,0,'compare');
h = legend('cos(x/4)','sin(x/8)','Northwest');