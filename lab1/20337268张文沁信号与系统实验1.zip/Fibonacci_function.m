function[a_new] = Fibonacci_function(a1,a2,max)
    a_new = 1;
    while(a_new < max)
        index = a_new;
        a_new = a1 + a2;
        a1 = a2;
        a2 = index;
    end
end