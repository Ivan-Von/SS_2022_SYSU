%赋值
a = 'hello';
b = 365;
c = 2;
%数值
    %为了稳定性应该把i/j写成1i
d = b + c * 1i;
e = b*exp(1i*b);
%矩阵
    %矩阵的创建
A = [1,2,3;4,5,6;7,8,9];
B = [9,8,7
     6,5,4
     3,2,1];
C = ones(2*3); %生成2*3的全1矩阵
D = zeros(2*3);%生成2*3的全0矩阵
E = eye(2*3);  %生成2*3的单位矩阵
F = rand(2*3); %生成2*3的随机矩阵
    %矩阵的下标 注意都从1开始
X = A(1,1) + A(2,2) + A(3,3);%对角线之和
    %矩阵相关函数
[m,n] = size(A);%n = length(A)同样的效果
sum(A);
p = max(A);
%程序流程控制
    %循环
s = 0;
for i = 1:2:99
    s = s + 1;
end

while i < 99
    s = s + 2;
end
    %条件语句
if i < 99
    s = 0;
else 
    s = 99;
end

switch s
    case 99
        s = 0;
    case 1
        s = 99;
    otherwise
        s = 100;
end
