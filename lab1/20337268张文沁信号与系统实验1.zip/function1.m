%function [outputArg1,outputArg2] = functio(inputArg1,inputArg2)
%FUNCTIO 此处显示有关此函数的摘要
%   此处显示详细说明
%outputArg1 = inputArg1;
%outputArg2 = inputArg2;
%end

function[s,m] = function1(a)
    l = length(a);
    s = sum(a);
    m = s/l;
end
%在命令行进行调用
%a = 1:9;
%[s,m] = function1(a);