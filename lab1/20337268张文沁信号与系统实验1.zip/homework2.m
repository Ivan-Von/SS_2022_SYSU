x = 0:0.5:16;%x轴
figure(1);

subplot(1,2,1);%分图像
plot(x,cos((x*pi)/4),'--r');%函数图
title('Figure for cos(xpi/4)')%标题
xlabel('X');%x的标注
ylabel('cos(xpi/4)');%y的标注
g = legend('cos(xpi/4)','Best');%图例
text(0,0,'O1');%一个注记

subplot(1,2,2);%分图像
plot(x,sin((x*pi)/8),'*-b');%函数图
title('Figure for sin(xpi/8)')%标题
xlabel('X');%x的标注
ylabel('sin(xpi/8)');%y的标注
h = legend('sin(xpi/8)','Best');%图例
text(0,0,'O2');%一个注记
