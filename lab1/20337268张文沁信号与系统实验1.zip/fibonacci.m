a1 = 1;
a2 = 1;
a_new = 1;
while(a_new < 10000)
    index = a_new;
    a_new = a1 + a2;
    a1 = a2;
    a2 = index;
end
disp(a_new)